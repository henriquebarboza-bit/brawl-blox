BRAWL BLOX — VERSÃO FINAL CORRIGIDA

Correções principais:
1. Corrigido o travamento no primeiro ataque: o arquivo anterior chamava burst() sem que a função existisse.
2. Sistema de projéteis refeito para remover o projétil com segurança após o acerto.
3. O dano reduz o HP do oponente e, ao chegar a 0, o inimigo é marcado como morto e removido da arena.
4. Inimigos mortos não podem mais receber dano, atacar ou bloquear o jogador.
5. Efeito visual de dano incluído sem depender de funções inexistentes.
6. Loop do jogo protegido para continuar funcionando mesmo se surgir outro erro de JavaScript.

Para o GitHub Pages, envie SOMENTE o index.html para a raiz do repositório.
