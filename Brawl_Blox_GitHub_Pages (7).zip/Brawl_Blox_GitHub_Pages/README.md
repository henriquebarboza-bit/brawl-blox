# Brawl Blox

Jogo web desenvolvido em HTML, CSS e JavaScript.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub, por exemplo `brawl-blox`.
2. Envie o arquivo `index.html` deste projeto para o repositório.
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.
7. O GitHub mostrará o endereço público do jogo.

O jogo é um projeto web estático: não precisa de servidor para funcionar.
